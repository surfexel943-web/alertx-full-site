"use strict";

let selectedNeed = null;
let selectedIcon = null;
let selectedRating = 0;
let attachedLocation = null;
let sosTimer = null;
let sosCancelled = false;

const networkStatus = document.getElementById("networkStatus");
const sosButton = document.getElementById("sosButton");
const sosModal = document.getElementById("sosModal");
const countdown = document.getElementById("countdown");
const cancelSOS = document.getElementById("cancelSOS");
const needModal = document.getElementById("needModal");
const closeNeedModal = document.getElementById("closeNeedModal");
const modalTitle = document.getElementById("modalTitle");
const modalIcon = document.getElementById("modalIcon");
const helpForm = document.getElementById("helpForm");
const helpDescription = document.getElementById("helpDescription");
const locationButton = document.getElementById("locationButton");
const locationStatus = document.getElementById("locationStatus");
const requestList = document.getElementById("requestList");
const toast = document.getElementById("toast");
const toastMessage = document.getElementById("toastMessage");
const feedbackForm = document.getElementById("feedbackForm");

function getRequests() {
    try {
        return JSON.parse(localStorage.getItem("alertx_requests")) || [];
    } catch (error) {
        return [];
    }
}

function saveRequests(requests) {
    localStorage.setItem("alertx_requests", JSON.stringify(requests));
}

let toastTimer = null;
function showToast(message) {
    toastMessage.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toast.classList.remove("show"); }, 3000);
}

function updateNetworkStatus() {
    if (navigator.onLine) {
        networkStatus.textContent = "● Online";
        networkStatus.classList.remove("offline");
        networkStatus.classList.add("online");
        syncOfflineRequests();
    } else {
        networkStatus.textContent = "● Offline mode";
        networkStatus.classList.remove("online");
        networkStatus.classList.add("offline");
    }
}

window.addEventListener("online", updateNetworkStatus);
window.addEventListener("offline", updateNetworkStatus);

sosButton.addEventListener("click", startSOS);

function startSOS() {
    sosCancelled = false;
    let seconds = 5;
    countdown.textContent = seconds;
    sosModal.classList.remove("hidden");
    requestLocationForSOS();
    clearInterval(sosTimer);
    sosTimer = setInterval(() => {
        seconds--;
        countdown.textContent = seconds;
        if (seconds <= 0) {
            clearInterval(sosTimer);
            if (!sosCancelled) {
                completeSOS();
            }
        }
    }, 1000);
}

cancelSOS.addEventListener("click", () => {
    sosCancelled = true;
    clearInterval(sosTimer);
    sosModal.classList.add("hidden");
    showToast("SOS cancelled");
});

function completeSOS() {
    sosModal.classList.add("hidden");
    const request = {
        id: createRequestId(),
        type: "SOS",
        icon: "🆘",
        description: "Emergency SOS request",
        location: attachedLocation,
        createdAt: new Date().toISOString(),
        status: navigator.onLine ? "sent" : "queued"
    };
    addRequest(request);
    if (navigator.onLine) {
        showToast("SOS sent to the emergency network");
    } else {
        showToast("SOS saved offline and will sync when network returns");
    }
    attachedLocation = null;
}

function requestLocationForSOS() {
    if (!navigator.geolocation) {
        attachedLocation = null;
        return;
    }
    navigator.geolocation.getCurrentPosition(
        position => {
            attachedLocation = {
                latitude: position.coords.latitude,
                longitude: position.coords.longitude,
                accuracy: position.coords.accuracy
            };
        },
        error => {
            console.warn("Location unavailable", error);
            attachedLocation = null;
        },
        { enableHighAccuracy: true, timeout: 8000, maximumAge: 30000 }
    );
}

locationButton.addEventListener("click", attachLocation);

function attachLocation() {
    if (!navigator.geolocation) {
        locationStatus.textContent = "Location is not supported";
        return;
    }
    locationStatus.textContent = "Getting your location...";
    navigator.geolocation.getCurrentPosition(
        position => {
            attachedLocation = {
                latitude: position.coords.latitude,
                longitude: position.coords.longitude,
                accuracy: position.coords.accuracy
            };
            locationStatus.textContent = `Location attached (${Math.round(position.coords.accuracy)}m accuracy)`;
            locationButton.textContent = "Location Attached";
            showToast("Location attached");
        },
        error => {
            locationStatus.textContent = "Unable to access location";
            showToast("Please allow location access");
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 }
    );
}

document.querySelectorAll(".need-card").forEach(card => {
    card.addEventListener("click", () => {
        selectedNeed = card.dataset.type;
        selectedIcon = card.dataset.icon;
        modalTitle.textContent = selectedNeed + " Help";
        modalIcon.textContent = selectedIcon;
        helpDescription.value = "";
        attachedLocation = null;
        locationStatus.textContent = "Location not attached";
        locationButton.textContent = "Attach Location";
        needModal.classList.remove("hidden");
    });
});

closeNeedModal.addEventListener("click", closeNeed);

needModal.addEventListener("click", event => {
    if (event.target === needModal) {
        closeNeed();
    }
});

function closeNeed() {
    needModal.classList.add("hidden");
    selectedNeed = null;
    attachedLocation = null;
}

helpForm.addEventListener("submit", event => {
    event.preventDefault();
    if (!selectedNeed) {
        return;
    }
    const request = {
        id: createRequestId(),
        type: selectedNeed,
        icon: selectedIcon,
        description: helpDescription.value.trim(),
        name: document.getElementById("userName").value.trim(),
        phone: document.getElementById("phoneNumber").value.trim(),
        location: attachedLocation,
        createdAt: new Date().toISOString(),
        status: navigator.onLine ? "sent" : "queued"
    };
    addRequest(request);
    closeNeed();
    helpForm.reset();
    if (navigator.onLine) {
        showToast(`${request.type} request sent`);
    } else {
        showToast("Request saved offline");
    }
});

function createRequestId() {
    return (
        "AX-" +
        Date.now().toString(36).toUpperCase() +
        "-" +
        Math.random().toString(36).substring(2, 6).toUpperCase()
    );
}

function addRequest(request) {
    const requests = getRequests();
    requests.unshift(request);
    saveRequests(requests);
    renderRequests();
}

function renderRequests() {
    const requests = getRequests();
    if (!requests.length) {
        requestList.innerHTML = `
            <div class="empty-state">
                <span>📋</span>
                <p>No active requests</p>
                <small>Your requests will appear here.</small>
            </div>
        `;
        return;
    }
    requestList.innerHTML = requests.map(request => {
        const date = new Date(request.createdAt).toLocaleString();
        const statusText = {
            queued: "Waiting for network",
            sent: "Request sent",
            received: "Help centre received",
        }[request.status] || "Processing";
        return `
            <div class="request-card">
                <div class="request-main">
                    <div class="request-icon">${request.icon}</div>
                    <div>
                        <h3>${escapeHTML(request.type)}</h3>
                        <p>${escapeHTML(request.description)}</p>
                        <p>${date}</p>
                        ${request.location ? `<p>📍 Location attached</p>` : `<p>📍 Location not attached</p>`}
                    </div>
                </div>
                <span class="status ${request.status}">${statusText}</span>
            </div>
        `;
    }).join("");
}

function syncOfflineRequests() {
    if (!navigator.onLine) {
        return;
    }
    const requests = getRequests();
    let changed = false;
    requests.forEach(request => {
        if (request.status === "queued") {
            request.status = "sent";
            changed = true;
        }
    });
    if (changed) {
        saveRequests(requests);
        renderRequests();
        showToast("Offline requests synchronized");
    }
}

document.querySelectorAll("#stars button").forEach(button => {
    button.addEventListener("click", () => {
        selectedRating = Number(button.dataset.rating);
        document.querySelectorAll("#stars button").forEach(star => {
            const rating = Number(star.dataset.rating);
            star.classList.toggle("active", rating <= selectedRating);
        });
    });
});

feedbackForm.addEventListener("submit", event => {
    event.preventDefault();
    const feedback = document.getElementById("feedback").value.trim();
    if (!feedback) {
        return;
    }
    const feedbackData = {
        message: feedback,
        rating: selectedRating,
        createdAt: new Date().toISOString()
    };
    const oldFeedback = JSON.parse(localStorage.getItem("alertx_feedback")) || [];
    oldFeedback.push(feedbackData);
    localStorage.setItem("alertx_feedback", JSON.stringify(oldFeedback));
    feedbackForm.reset();
    selectedRating = 0;
    document.querySelectorAll("#stars button").forEach(star => { star.classList.remove("active"); });
    showToast("Thank you for your feedback");
});

function escapeHTML(value) {
    return String(value || "").replace(/[&<>"']/g, character => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
    })[character]);
}

if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
        navigator.serviceWorker.register("sw.js")
            .then(() => { console.log("AlertX offline service worker registered"); })
            .catch(error => { console.log("Service worker error:", error); });
    });
}

updateNetworkStatus();
renderRequests();
